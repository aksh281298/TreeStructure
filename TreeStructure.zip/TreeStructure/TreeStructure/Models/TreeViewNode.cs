﻿namespace TreeStructure.Models
{
    public class TreeViewNode
    {
        public string Id { get; set; }
        public string Parent { get; set; }
        public string Text { get; set; }
    }
}
