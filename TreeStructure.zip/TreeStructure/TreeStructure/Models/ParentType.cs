﻿namespace TreeStructure.Models
{
    public class ParentType
    {
        public int parentId { get; set; }
        public string parentName { get; set; }
    }
}
